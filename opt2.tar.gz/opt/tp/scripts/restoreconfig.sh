#!/bin/bash

dir="/opt/tp/firewall/firewall.conf"

iptables-restore < "$dir"
echo "reglas de firewall cargadas exitosamente desde $dir"
