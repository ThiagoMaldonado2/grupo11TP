#!/bin/bash

ARGS="$*"
dest=$1


etc=$2
log=$3
u01=$4
u02=$5

day=$(date +%Y%m%d)
etc_name="etc_bkp_$day.tar.gz"
log_name="log_bkp_$day.tar.gz"
u01_name="u01_bkp_$day.tar.gz"
u02_name="u02_bkp_$day.tar.gz"

hoy=$(date +%a)
sun="dom"
hora=$(date +H)
cero="00"
vt="23"

time=$(date +%H:%M:%S)

hora00() {
	touch log$time
	mv /opt/tp/scripts/log$time /opt/tp/logs
	echo "$time realizando backup de /etc y /log" > /opt/tp/logs/log$time
}

hora23() {
	touch log$time
	mv /opt/tp/scripts/log$time /opt/tp/logs
	echo "$time realizando backup de /u01 y /u02" > /opt/tp/logs/log$time
}

if [ "$1" = "-h" ]; then
	echo "el script tiene que ser ejecutado con los argumentos /u03 /etc /var/log /u01 /u02"
else

if [ -e /u03 ]; then
	
	if [ -e /etc ]; then

		if [ "${hora}" = "${cero}" ]; then
		tar -zcvf $dest/$etc_name $etc
		hora00

		else
			echo "no son las 12"
		fi
	else
		echo "no existe etc"
	
	fi


	if [ -e /var/log ]; then

		if [ "${hora}" = "${cero}" ]; then
			tar -zcvf $dest/$log_name $log
			hora00
			
		else
			echo "no son las 12"
		fi
	else
		echo "no existe log"
	fi

	if [ -e /u01 ]; then
		
		if [ "${hoy}" = "${sun}" ] && [ "${hora}" = "${vt}" ]; then
			tar -zcvf $dest/$u01_name $u01
			hora23
			
		else
			echo "no es domingo"
		fi
	else
		echo "no existe u01"
	
	fi

	if [ -e /u02 ]; then
		if [ "${hoy}" = "${sun}" ] && [ "${hora}" = "${vt}" ]; then
			tar -zcvf $dest/$u02_name $u02
			hora23
			
		else
			echo "no es domingo"
		fi
	else
		echo "no existe u02"
	fi
else
	echo "no existe u03"
fi

mutt -s "logs" -a log$time.txt -- root

echo 
echo "backup terminado"
date
fi
