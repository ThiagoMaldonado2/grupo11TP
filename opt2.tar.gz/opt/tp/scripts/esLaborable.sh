#!/bin/bash


esLaborable() {
	fecha=$1
	dia_semana=$(date -d "$fecha" +"%u")
	dia_mes=$(date -d "$fecha" +"%d/%m")
	declare -i valorRetorno=0

	if [ $dia_semana -eq 6 ] || [ $dia_semana -eq 7 ]; then
		echo "$fecha no es laborable por fin de semana"
		valorRetorno=1
	fi

	case $dia_mes in
		"01/01" | "24/03" | "02/04" | "01/05" | "25/05" | "20/06" | "09/07" | "08/12" | "25/12" | "17/08" | "12/10" | "20/11" )
		echo "La fecha no es laborable, es un feriado nacional"
		if [ $dia_semana -eq 2 ]; then
			echo "El feriado nacional cae martes, por consecuencia, el lunes es feriado tambien."
		elif [ $dia_semana -eq 4 ]; then
			echo "El feriado nacional cae jueves, por consecuencia, el viernes es feriado tambien"
		fi
		valorRetorno=1
	esac
	case $dia_mes  in
		"17/08" ) 
		echo "La fecha $fecha es el feriado nacional del 17 de agosto cumplido el tercer lunes de ese mes. no es laborable."
		valorRetorno=1
		;;

		"12/10" ) 
		echo "La fecha $fecha es el feriado nacional del 12 de octubre cumplido el segundo lunes de ese mes. no es laborable"
		valorRetorno=1
		;;

		"20/11" )
		echo "La fecha $fecha es el feriado nacional del 20 de noviembre cumplido el cuarto lunes de ese mes. no es laborable"
		valorRetorno=1
		;;
	esac

	case $dia_mes in	
		"02/10" | "03/10" | "04/10" )
		echo "Si profesas la religion judia, desde la tarde del dia 2 de octubre hasta la tarde del 4 de octubre es dia no laborable debido a que se celebra el año nuevo judio."
		valorRetorno=1
		;;

		"11/10" | "12/10" ) 
		echo "Si profesas la religion judia, desde la tarde del 11 de octubre hasta la tarde del 12 de octubre es dia no laborable debido a que se celebra el dia del perdon."
		valorRetorno=1
		;;

		"22/04" | "23/04" | "29/04" | "30/04" )
		echo "Si profesas la religion judia, los dias 22,23,29 y 30 de abril del 2024 son dias no laborables debido a que se celebra la pascua judia."
		valorRetorno=1
		;;
	esac
	
	case $dia_mes in
		"06/07" | "07/07" )
		echo "Si profesas la religion musulmana, desde la tarde del 6 de julio hasta la tarde del 7 de julio es dia no laborable debido a que se celebra el año nuevo musulman."
		valorRetorno=1
		;;

		"11/04" )
		echo "Si profesas la religion musulmana, el 11 de abril del 2024 es dia no laborable debido a que es el dia posterior a la culminacion del ayuno."
		valorRetorno=1
		;;

		"16/06" | "17/06" | "18/06" | "19/06" | "20/06" )
		echo "Si profesas la religion musulmana, desde la tarde del 17 de junio hasta la tarde del 20 de junio del 2024 son dias no laborables debido a que se celebra la fiesta del sacrificio."
		valorRetorno=1
		;;
	esac

	

	return ${valorRetorno}




}

